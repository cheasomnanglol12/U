# SSN Security Tips! - https://t.me/tcpsyn

1. Set up your API with Cloudflare! (https://cloudflare.com)
*How To*
Message in https://t.me/c/1559885860/286294 on Telegram!

2. Whitelist so ONLY Cloudflare IP addresses can connect to your API!
*How To*
Message in https://t.me/c/1559885860/286294 on Telegram!

3. Set up SSN Proxy to protect your backend! (https://t.me/tcpsynack Pinned)
*How To*
Message in https://t.me/c/1559885860/286294 on Telegram!

4. Whitelist so ONLY your SSN Proxy IP addresses can connect to your CNC!
*How To*
Message in https://t.me/c/1559885860/286294 on Telegram!